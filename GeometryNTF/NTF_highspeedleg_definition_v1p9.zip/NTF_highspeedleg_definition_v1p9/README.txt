Release 1.9 of National Transonic Facility (NTF) high-speed leg geometry, in inches*
June 26, 2025
IGES, STEP, and X_T geometry types provided (prepared by S. Brynildsen of GEOLAB, NASA LARC)

NTF_Contraction_TestSection_Diffusor_2023_10_02          - baseline test section, simplified plenum, contraction, and diffuser;
                                                           note that some simplifications have been made in the CAD,
                                                           particularly in the plenum
NTF_TestSection_Baseline_in_Plenum_2023_10_02            - baseline test section and simplified plenum, in case it is wanted separately
NTF_Inlet_Contraction_2023_10_02                         - inlet contraction, in case it is wanted separately
NTF_Diffusor_2023_10_02                                  - diffuser, in case it is wanted separately
NTF_Diffusor_Constant_Cross_Section_Extension_2023_10_02 - arbitrary extension to diffuser (NOT REAL - this type of
                                                           geometry is sometimes used by CFD to extend the outflow
                                                           plane of the high-speed leg further downstream)
NTF_Additional_Obstructions_2023_10_02                   - additional obstructions in the plenum, if desired
NTF_Arc_Sector_CameraPod_2023_10_02                      - camera pod often placed on the end of the sting hub when
                                                           doing wall-mounted tests
NTF_Arc_Sector_Rotational_Axis_Cylinder_2023_10_02       - rotational axis for aid in rotating the arc sector
NTF_Arc_Sector_Straight_Sting_0deg_2023_10_02            - straight sting extension (not used in CRM-HL test)
NTF_USS_Sting_noRotation_2025_04_21                      - upper swept strut (USS), which connects to the arc sector
                                                           and serves as a sting, connecting like a vertical tail to
                                                           the full-span CRM-HL 2.7% full span model; the arcsector
                                                           and USS get rotated 6.43 deg when the CRM-HL is at 0 deg;
                                                           also includes a clamshell part near the attachment to the model
NTF_arc_sector_aft_fixed                                 - back part of arc sector, which does not move
NTF_arc_sector_fwd_rotational_0deg                       - front part of arc sector (including sting hub), set at 0 deg;
                                                           can be rotated using NTF_Arc_Sector_Rotational_Axis_Cylinder_2023_10_02;
                                                           Note that part of the bulge on the sides of this part extend over
                                                           the non-moving back part of the arcsector on both sides, sliding 
                                                           "over" it as the front part rotates; Note that the arcsector can
                                                           be rotated up -11 deg (sting hub pointing downward), and can be
                                                           rotated down +19 deg (sting hub pointing upward); when rotating down
                                                           (in reality) there are floor plates that can hinge out of the way to allow
                                                           the sting hub and bulge on the sides of the arcsector to pass
                                                           through the floor; for simplicity, the CAD simply intersects the 
                                                           rotating parts with the floor; the outer shell of the plenum also
                                                           in reality has protrusions (left out of the CAD) that allow the
                                                           arcsector to rotate to high angles - in the current CAD the
                                                           arcsector part simply penetrates the outer shell
                                                           See the file: arc_sector_rotations_sketches.pdf
how_mounted_2p7.txt                                      - file details the coordinate transformation to go from the full-scale CRM
                                                           vehicle to a 2.7% scale full-span, upper-swept-strut-mounted vehicle;
                                                           these transformations are valid for any of the CRM family of vehicles
                                                           (CRM, CRM-HL, CRM-NLF)
how_mounted_2p7semispan.txt                              - file details the coordinate transformation to go from the full-scale CRM
                                                           vehicle to a 2.7% scale semispan, sidewall-mounted vehicle; these
                                                           transformations are valid for any of the CRM family of vehicles (CRM,
                                                           CRM-HL, CRM-NLF)
how_mounted_5p2semispan.txt                              - file details the coordinate transformation to go from the full-scale CRM
                                                           vehicle to a 5.2% scale semispan, sidewall-mounted vehicle; these
                                                           transformations are valid for any of the CRM family of vehicles (CRM,
                                                           CRM-HL, CRM-NLF)

* Note that the units of x_t geometry files always defaults to meters, but the intent is to provide the geometry in inches

The release version number of the geometry should be mentioned in any report/publication.

Recommended: NASA TM 110242 "User's Guide for the National Transonic Facility Research Data System" (Foster & Adcock), April 1996.



Changes from release 1.8: Updated and enhanced coordinate system transformations for the CRM family of vehicles.
                              - Transformations for the 2.7% full-span model have not been updated.
                              - The transformations for the 5.2% sidewall have been updated from V1.8, which mistakenly changed the 
                                y offset to 2.25 inches. The y offset is 2.0 inches. The equations were also cleaned up, but the
                                transformations end up exactly the same as was given for the 5.2% sidewall-mounted model in V1.7 and
                                prior
                              - New transformations are given for the 2.7% sidewall-mounted vehicle.
                          Organized files to clarify which ones are assemblies and others that are supporting parts.
                          Added 2025 AVIATION paper.

Changes from release 1.7: The standoff distance between the 5.2% scale fuselage centerline and wind tunnel wall was updated from 
                          approximately 2.0 inches to 2.25 inches. The 2.25 inch standoff includes an approximately 2 inch plate and
                          also a 0.25 inch gap. Details are included in how_mounted_5p2.txt.

Changes from release 1.6: A small clamshell part was previously missing from the X_T and IGES versions of the file:
                          NTF_USS_Sting_noRotation_2024_08_15.
                          The STEP version of this file DID include the clamshell.
                          The file has now been replaced by the following:
                          NTF_USS_Sting_noRotation_2025_04_21.  The STEP version of this file is the same as it was before.
                          All versions (X_T, IGES, and STEP) versions of this file now include the clamshell part.
                          Added the coordinate transformations for 2.7% full-span CRM (how_mounted_2p7.txt) and 5.2%
                          sidewall-mounted CRM (how_mounted_5p2.txt)

Changes from release 1.5: Replaced the part NTF_Arc_Sector_wStingHub_Sym_0deg_2023_10_02 with 2 new parts:
                          NTF_arc_sector_aft_fixed and NTF_arc_sector_fwd_rotational_0deg;
                          this is because only the front part of the arcsector rotates; the back part is fixed.
                          Additional descriptions regarding the movement of the arcsector have been added.

Changes from release 1.4: Removed the part NTF_Arc_Sector_TopLoadingSting_0deg_2023_10_02, and replaced it with a better
                          representation of the upper swept strut (USS): NTF_USS_Sting_noRotation_2024_08_15
                          This representation was deduced from laser scans and existing CAD parts and photographs

Changes from release 1.3: Created a combined NTF_Contraction_TestSection_Diffusor_2023_10_02 part

Changes from release 1.2: Repositioned everything so that the tunnel 0 corresponds to that used in the real tunnel
                          (previous versions were about 64 inches off!)
                          Removed the file:
                              - NTF_Arc_Sector_and_Sting_0deg_2023_06_09
                          Added the files:
                              - NTF_Arc_Sector_CameraPod_2023_10_02
                              - NTF_Arc_Sector_Rotational_Axis_Cylinder_2023_10_02
                              - NTF_Arc_Sector_Straight_Sting_0deg_2023_10_02
                              - NTF_Arc_Sector_TopLoadingSting_0deg_2023_10_02
                              - NTF_Arc_Sector_wStingHub_Sym_0deg_2023_10_02

Changes from Release 1.1: Revised README.txt file, indicating that the geometry is given in inches

Changes from Release 1.0: Revised README.txt file, for greater clarity
